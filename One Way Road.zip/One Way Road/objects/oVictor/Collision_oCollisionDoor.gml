room_goto_next();
x = oCollisionDoor.target_x;
y = oCollisionDoor.target_y;