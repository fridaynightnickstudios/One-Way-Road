room_goto_previous();
x = oCollisionDoor2.target_x;
y = oCollisionDoor2.target_y;